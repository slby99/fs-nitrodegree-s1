package com.example.twoactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tv_activity1;
    Button btn_send_activity1;
    EditText et_activity1;
    public final static String EXTRA_MESSAGE = "com.example.twoactivities.ACTIVITYMSG1";
    public final static String EXTRA_MESSAGE2 = "com.example.twoactivities.ACTIVITYMSG2";
    final static int REQUESTCODE_ONE = 1;

    // First callback function -> Created state
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.i(TAG,"onCreate() called");

        tv_activity1 = (TextView) findViewById(R.id.tv_activity1);
        btn_send_activity1 = findViewById(R.id.btn_send_activity1);
        et_activity1 = findViewById(R.id.et_activity1);
        // tv_activity1 = findViewById<TextView>(R.id.tv_activity1)
    }

    public void StartSecondActivity(View view) {
        Intent secondActivityIntent = new Intent(this,SecondActivity.class);
        String message = et_activity1.getText().toString();
        secondActivityIntent.putExtra(EXTRA_MESSAGE,message);
        secondActivityIntent.putExtra(EXTRA_MESSAGE2,"Secret code: 11111");
        startActivityForResult(secondActivityIntent,REQUESTCODE_ONE);
        //startActivity(secondActivityIntent);
    }

    // Callback function to receive the data from SecondActivity
    // startActivityForResult is a pair to onActivityResult
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUESTCODE_ONE) {
            if(resultCode == RESULT_OK) {
                String message = data.getStringExtra(SecondActivity.EXTRA_MESSAGE);
                //System.out.println(message);
                Log.d("TEST",message);
                tv_activity1.setText(tv_activity1.getText().toString() + message);
            }
            else {
                tv_activity1.setText("Message Error!");
            }
        }

    }

    // Lifecycle callback methods
    String TAG = "LIFECYCLE";
    // val TAG = "LIFE"
    protected void onStart() {
        super.onStart();
        Log.i(TAG,"onStart() called");
    }

    protected void onRestart() {
        super.onRestart();
        Log.i(TAG,"onRestart() called");
    }

    // override fun onStart() { }

    protected void onResume() {
        super.onResume();
        Log.i(TAG,"onResume() called");
    }

    protected void onPause() {
        super.onPause();
        Log.i(TAG,"onPause() called");
    }

    protected void onStop() {
        super.onStop();
        Log.i(TAG,"onStop() called");
    }

    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG,"onDestroy() called");
    }

    // Kotlin
//    override fun onStart() {
//        super.onStart()
//    }
}