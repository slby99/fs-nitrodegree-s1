package com.example.twoactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    TextView tv_activity2;
    EditText et_activity2;

    public final static String EXTRA_MESSAGE = "com.example.twoactivities.ACTIVITY2MSG";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        tv_activity2 = findViewById(R.id.tv_activity2);
        et_activity2 = findViewById(R.id.et_activity2);

        // Extract the message on the destination
        Intent intent = getIntent();
        String msg1 = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);
        String msg2 = intent.getStringExtra(MainActivity.EXTRA_MESSAGE2);

        tv_activity2.setText(tv_activity2.getText().toString() + msg1 + msg2);
    }

    public void StartFirstActivity(View view) {
        Intent replyIntent = new Intent(SecondActivity.this,MainActivity.class);
        String message = et_activity2.getText().toString();
        replyIntent.putExtra(EXTRA_MESSAGE,message);
        setResult(RESULT_OK, replyIntent); //Status code -1
        finish(); // close the current SecondActivity destroy
    }
}

