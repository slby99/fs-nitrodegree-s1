// https://developer.android.com/training/basics/intents/result
// https://developer.android.com/codelabs/android-training-create-an-activity?index=..%2F..%2Fandroid-training#0

package com.example.android.twoactivities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

/**
 * The TwoActivities app contains two activities and sends messages
 * (intents) between them.
 */
public class MainActivity extends AppCompatActivity {
    // Class name for Log tag
    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    // Unique tag required for the intent extra
    public static final String EXTRA_MESSAGE
            = "com.example.android.twoactivities.extra.MESSAGE";
    // Unique tag for the intent reply
    public static final int TEXT_REQUEST = 1;

    // EditText view for the message
    private EditText mMessageEditText;
    // TextView for the reply header
    private TextView mReplyHeadTextView;
    // TextView for the reply body
    private TextView mReplyTextView;

    /**
     * Initializes the activity.
     *
     * @param savedInstanceState The current state data.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize all the view variables.
        mMessageEditText = findViewById(R.id.editText_main);
        mReplyHeadTextView = findViewById(R.id.text_header_reply);
        mReplyTextView = findViewById(R.id.text_message_reply);
    }

    // registerForActivityResult
    // https://developer.android.com/training/basics/intents/result
    // https://medium.com/realm/startactivityforresult-is-deprecated-82888d149f5d
    // https://stackoverflow.com/questions/62671106/onactivityresult-method-is-deprecated-what-is-the-alternative
    // https://stackoverflow.com/questions/67886839/how-to-get-requestcode-from-activity-result-api
    ActivityResultLauncher<Intent> startActivityForResult = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == AppCompatActivity.RESULT_OK) {
                    Intent data = result.getData();
                    // ...
                }

                // Test for the right intent reply.
                //if (requestCode == TEXT_REQUEST) {
                // Test to make sure the intent reply result was good.
                if (result.getResultCode() == RESULT_OK) {
                    Intent data = result.getData();
                    String reply = data.getStringExtra(SecondActivity.EXTRA_REPLY);

                    // Make the reply head visible.
                    mReplyHeadTextView.setVisibility(View.VISIBLE);

                    // Set the reply and make it visible.
                    mReplyTextView.setText(reply);
                    mReplyTextView.setVisibility(View.VISIBLE);
                }
                //}
            }
    );
    /**
     * Handles the onClick for the "Send" button. Gets the value of the main EditText,
     * creates an intent, and launches the second activity with that intent.
     *
     * The return intent from the second activity is onActivityResult().
     *
     * @param view The view (Button) that was clicked.
     */
    public void launchSecondActivity(View view) {
        Log.d(LOG_TAG, "Button clicked!");
        Intent intent = new Intent(this, SecondActivity.class);
        String message = mMessageEditText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, message);
        //startActivityForResult(intent, TEXT_REQUEST);




        startActivityForResult.launch(intent);
    }

    /**
     * Handles the data in the return intent from SecondActivity.
     *
     * @param requestCode Code for the SecondActivity request.
     * @param resultCode Code that comes back from SecondActivity.
     * @param data Intent data sent back from SecondActivity.
     */
//    @Override
//    public void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//
//        // Test for the right intent reply.
//        if (requestCode == TEXT_REQUEST) {
//            // Test to make sure the intent reply result was good.
//            if (resultCode == RESULT_OK) {
//                String reply = data.getStringExtra(SecondActivity.EXTRA_REPLY);
//
//                // Make the reply head visible.
//                mReplyHeadTextView.setVisibility(View.VISIBLE);
//
//                // Set the reply and make it visible.
//                mReplyTextView.setText(reply);
//                mReplyTextView.setVisibility(View.VISIBLE);
//            }
//        }
//    }
}
