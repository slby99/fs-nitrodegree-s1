package com.example.twoactivitiesnewkotlin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : AppCompatActivity() {
    // Class name for Log tag
    private val LOG_TAG = MainActivity::class.java.simpleName

    companion object {
        // Unique tag required for the intent extra
        const val EXTRA_MESSAGE = "com.example.android.twoactivities.extra.MESSAGE"
    }

    // Unique tag for the intent reply
    val TEXT_REQUEST = 1

    // EditText view for the message
    private var mMessageEditText: EditText? = null

    // TextView for the reply header
    private var mReplyHeadTextView: TextView? = null

    // TextView for the reply body
    private var mReplyTextView: TextView? = null

    /**
     * Initializes the activity.
     *
     * @param savedInstanceState The current state data.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize all the view variables.
        mMessageEditText = findViewById(R.id.editText_main)
        mReplyHeadTextView = findViewById(R.id.text_header_reply)
        mReplyTextView = findViewById(R.id.text_message_reply)
    }

    // registerForActivityResult
    // https://developer.android.com/training/basics/intents/result
    // https://medium.com/realm/startactivityforresult-is-deprecated-82888d149f5d
    // https://stackoverflow.com/questions/62671106/onactivityresult-method-is-deprecated-what-is-the-alternative
    // https://stackoverflow.com/questions/67886839/how-to-get-requestcode-from-activity-result-api
    var startActivityForResult: ActivityResultLauncher<Intent> =
        registerForActivityResult<Intent, ActivityResult>(
            ActivityResultContracts.StartActivityForResult(),
            ActivityResultCallback { result: ActivityResult ->
                if (result.resultCode == RESULT_OK) {
                    val data = result.data
                    // ...
                }

                // Test for the right intent reply.
                //if (requestCode == TEXT_REQUEST) {
                // Test to make sure the intent reply result was good.
                if (result.resultCode == RESULT_OK) {
                    val data = result.data
                    val reply = data!!.getStringExtra(SecondActivity.EXTRA_REPLY)

                    // Make the reply head visible.
                    mReplyHeadTextView!!.visibility = View.VISIBLE

                    // Set the reply and make it visible.
                    mReplyTextView!!.text = reply
                    mReplyTextView!!.visibility = View.VISIBLE
                }
            }
        )

    /**
     * Handles the onClick for the "Send" button. Gets the value of the main EditText,
     * creates an intent, and launches the second activity with that intent.
     *
     * The return intent from the second activity is onActivityResult().
     *
     * @param view The view (Button) that was clicked.
     */
    fun launchSecondActivity(view: View?) {
        Log.d(LOG_TAG, "Button clicked!")
        val intent = Intent(this, SecondActivity::class.java)
        val message = mMessageEditText!!.text.toString()
        intent.putExtra(Companion.EXTRA_MESSAGE, message)
        //startActivityForResult(intent, TEXT_REQUEST);
        startActivityForResult.launch(intent)
    }
}